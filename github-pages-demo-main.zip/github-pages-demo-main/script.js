setTimeout(() => {
  const p = document.createElement("p");
  p.innerText = "and it's dynamic, too!";
  document.body.appendChild(p);
}, 2000);
